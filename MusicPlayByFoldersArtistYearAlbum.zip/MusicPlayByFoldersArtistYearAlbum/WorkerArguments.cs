﻿
namespace MusicManager
{
    internal class WorkerArguments
    {
        public string Artist { get; set; }
        public Utils.SearchType SearchType { get; set; }
    }
}
