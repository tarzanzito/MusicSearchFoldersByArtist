﻿using System;

namespace MusicManager
{
    internal class WorkerProcessState
    {
        public Utils.Collection Collection { get; set; }
        public string Artist { get; set; }
        public string Folder { get; set; }
    }
}
